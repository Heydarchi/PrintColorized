# PrintColorized
A python package to print colorized
