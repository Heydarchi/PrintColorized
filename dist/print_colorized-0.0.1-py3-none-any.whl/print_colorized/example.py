from PrintColorized import *

pColorized = PrintColorized()

pColorized=PrintColorized()
helpPrintColorized()
printNormal("Normal Bold Italic", italic=True, bold=True)
printWarning("Warning Bold underline", italic=True, underline=True)
